SyncFix 1.4.1

Requires Dalamud API 15. Open /syncfix or use the plugin installer.
Check shows installed managed plugin versions and loaded status. It works
anywhere and requires no other plugin. Local developer plugins are omitted.

For remote support, enter the support owner's access code and Save access once,
then click Start support. The code is protected for your Windows account.
Only the authenticated support owner can request fresh checks. End support
stops sharing. Sessions never start automatically and have no time limit.

Support sends the displayed managed-plugin status and SyncFix version to its
support relay on Wispbyte. It does not send character names, account keys,
locations, file paths or raw logs. Checks do not change settings or game state.
SyncFix cannot run arbitrary commands or repair plugins.

Install/update through the custom repository in Dalamud Settings, Experimental:
https://raw.githubusercontent.com/wallawallaslytherin/dalamud-plugins/main/pluginmaster.json
Search for SyncFix in the plugin installer.
