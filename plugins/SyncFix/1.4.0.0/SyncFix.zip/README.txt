SyncFix 1.4

Requires Dalamud API 15, PlayerSync and Stagehand.

Install
In Dalamud Settings, open Experimental and add this custom plugin repository:
https://raw.githubusercontent.com/wallawallaslytherin/dalamud-plugins/main/pluginmaster.json
In the plugin installer, search for SyncFix and click Install.

Use
Enter the estate and room containing the stage. Open SyncFix from the plugin
installer or run /syncfix. Enter the support owner's access code in Access code
and click Save access once. Then click Start support. Each approved installation
needs its own code. The saved code is protected for your Windows account.

Support has no time limit. End support stops it. Sessions do not start automatically.
Support can diagnose missing or disabled plugins, a disconnected PlayerSync
account and missing stages, even when PlayerSync shows zero visible stages.
The support service selects the stage and optional separate sky to check.
Checks are limited to those scenes and respect their access permissions.

During support, SyncFix sends stage/plugin status and plugin version numbers
to its support relay hosted on Wispbyte. The operator can check the results
and request fresh checks. SyncFix never changes subscriptions, settings or stages.
Account keys, character names, private locations and file paths are omitted.
Sessions stay in server memory until they end, access is revoked or the relay
restarts. Only the authenticated support owner can request checks. Connecting
performs diagnosis. Support cannot run
arbitrary commands or control other applications.

SyncFix cannot grant access denied by the stage owner or fix a server outage.
If support is unavailable, try Start support again. Check remains available
after a support stage has been selected. Repair commands are rejected.


