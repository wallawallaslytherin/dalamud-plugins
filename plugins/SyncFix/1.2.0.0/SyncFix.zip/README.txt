SyncFix 1.2.0

Requires Dalamud API 15, PlayerSync and Stagehand.

Install
In Dalamud Settings, open Experimental and add this custom plugin repository:
https://raw.githubusercontent.com/wallawallaslytherin/dalamud-plugins/main/pluginmaster.json
In the plugin installer, search for SyncFix and click Install.

Use
Enter the estate and room containing the stage. Open SyncFix from the plugin
installer or run /syncfix. Click Start support. Nothing needs to be entered or
copied; the support operator receives the session automatically.

Support lasts one hour. End support stops it. Sessions do not start automatically.
Support can diagnose missing or disabled plugins, a disconnected PlayerSync
account and missing stages, even when PlayerSync shows zero visible stages.
The support service selects the stage to check. Repairs are limited to that
stage and require its access permissions and matching house and room.

During support, SyncFix sends stage/plugin status and plugin version numbers
to its support relay hosted on Wispbyte. The operator can check the results
and request repairs: enable stage features, subscribe, resume or retry loading.
Account keys, character names, private locations and file paths are omitted.
Sessions stay in server memory until they end or expire. Support cannot run
arbitrary commands or control other applications.

SyncFix cannot grant access denied by the stage owner or fix a server outage.
If support is unavailable, try Start support again. Check and Fix sync remain
available after a support stage has been selected.
