Character Copy

Requires Dalamud API 15 on Windows.

Install this local testing build:
1. Extract the ZIP into a permanent folder. Keep all four files together.
2. In FFXIV, open /xlsettings, then Experimental, then Dev Plugin Locations.
3. Add the extracted CharacterSettingsCopy.dll and save the settings.
4. In /xlplugins, enable Character Copy if it is not already enabled.

Log into the character whose settings you want to copy. Open Character Copy
from the plugin installer or with /cc. Click the single copy button.
Stay on that character until completion. No external script is required.

The plugin first requests native character settings saves, then creates and
verifies a ZIP of the entire FFXIV settings directory. It copies EVERY file
and subfolder from the logged-in character to every other existing local
FFXIV_CHR folder. That includes UISAVE.DAT, strategy-board data, gearsets,
hotbars, macros, controls, chat history and all other files actually present.
Matching files on all other local characters are overwritten. Alt-only files
and character-folder IDs are preserved. It does not transfer server-side
inventory, progress or unlocks, or separately stored plugin settings.

Backups are kept under this plugin's private configuration directory, in
Backups. Keep them private: they contain all local characters and may contain
chat history and screenshots stored under the game settings folder.

For full rollback, open the plugin's configuration window and use Restore
latest backup at the title screen. The current directory is also preserved
beside the restored directory. A failed copy attempts automatic rollback.

Local testing candidate: file-engine tests passed; the plugin loaded with
zero Dalamud validation findings. The native save modules were checked
against the logged-in character. Actual native saving and the complete
in-game copy/recovery workflow have not been exercised.
