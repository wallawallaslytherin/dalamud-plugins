Character Copy

Requires Dalamud API 15 on Windows.

Install this local testing build:
1. Extract the ZIP into a permanent folder. Keep all four files together.
2. In FFXIV, open /xlsettings, then Experimental, then Dev Plugin Locations.
3. Add the extracted CharacterSettingsCopy.dll and save the settings.
4. In /xlplugins, enable Character Copy if it is not already enabled.

Log into the character whose settings you want to copy. Open Character Copy
from the plugin installer or with /cc. Check the source and destination count,
then click Copy to all other characters.
Stay on that character until completion. No external script is required.

To import from another character, open /cc and select the Import tab.
Choose From and Into, return to the title screen, then click Import settings
and confirm the displayed source and destination. Only the chosen destination
is changed. The source and other characters remain intact. Settings are read
from the source's existing local folder; no folder means no import source.
Character names/worlds are read from saved local AutoRetainer profile records
when available, and remembered from character selection and logged-in
characters. This needs no running AutoRetainer plugin. Unavailable names use
folder IDs. Known profiles display names/worlds without their folder IDs.
The last logged-in character is the default import destination. You can select
another destination. Title-screen UI is also available through the plugin's
Open Main UI/configuration controls.

The plugin first requests native character settings saves, then creates and
verifies a ZIP of the entire FFXIV settings directory. It copies EVERY file
and subfolder from the logged-in character to every other existing local
FFXIV_CHR folder. That includes UISAVE.DAT, strategy-board data, gearsets,
hotbars, macros, controls, chat history and all other files actually present.
Matching files on all other local characters are overwritten. Alt-only files
and character-folder IDs are preserved. It does not transfer server-side
inventory, progress or unlocks, or separately stored plugin settings.

Backups are kept under this plugin's private configuration directory, in
Backups. Keep them private: they contain all local characters and may contain
chat history and screenshots stored under the game settings folder.

Undo last copy restores overwritten files and removes files added by the
latest successful copy. It leaves the source character, global settings and
unrelated destination files alone. Undo is available while on the original
source character or at the title screen. It stops if copied destination files
have changed or are missing. The undo record survives plugin reloads, but is
available only for copies made with version 1.1 or later. Each successful copy
replaces the previous undo record; a successful undo consumes it.
Imports share that latest-transfer record and have Undo last import, available
only at the title screen. The original copy/undo behavior is preserved.

For full recovery, expand Full backup recovery or use /cc restore, then use
Restore latest full backup at the title screen. This replaces the entire
settings directory and requires confirmation. The current directory is also
preserved beside the restored directory. A failed copy attempts automatic
rollback. Undo preserves the displaced target folders in a .CharacterCopy-undo
directory beside the game settings directory. Keep recovery copies private.

Local testing candidate: copy, restore and undo file-engine tests passed.
Version 1.2 passed 102 synthetic checks. The saved-name reader also passed
targeted parsing checks. UI, lobby-name discovery, loaded-plugin
validation and in-game copy/import/undo/recovery remain unverified for this
version. Actual native saving has not been exercised end to end.
