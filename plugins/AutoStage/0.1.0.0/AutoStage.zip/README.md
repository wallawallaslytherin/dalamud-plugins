# AutoStage

Install and configure PlayerSync first. AutoStage uses Stagehand to display the venue.

Enter a configured estate to join its syncshell and load its active stages automatically. Stagehand is installed if missing. Existing disabled plugins and stages remain disabled.

Use `/autostage` to view status or retry a failed setup.
